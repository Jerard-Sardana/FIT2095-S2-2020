var mongoose = require('mongoose');

var bookSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    title: {
        type: String,
        required: true
    },
    isbn: {
        type: String,
        validate: {
            validator: function (isbnString) {
                return isbnString.length == 13;
            },
            message: 'ISBN should be 13 characters long'
        }
    },
    author: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Author'
    },
    pubdate: {
        type: Date,
        //default to now
    },
    summary:String 
});

module.exports = mongoose.model('Book', bookSchema);